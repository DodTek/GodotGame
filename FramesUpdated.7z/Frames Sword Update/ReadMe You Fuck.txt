Here are some explanation of how some things should know

-Platforms-

You may have noticed that the middle platform is missing, that's because it's meant for the ground tile to fit as such

-Darts Holes-

The holes are meant to put over a wall the far side of a wall, I did it this way so you can change the height from where the arrows come

-Spikes-

Made the Spikes, in a different file so when they appear they wont mess up with the Tile properties (basicly same sit that we mentioned with melee).
There's two sets of spikes, the frontSpikes are meant to be in front of the character while the backSpikes are meant to be behing.

-Jump-

There's a couple of frames of the character getting ready to jump, not many games really have this, so if you feel is working weird dont be affraid of discarding them

-Sword-

If you are able make it so when you press the attack the first time the frames where the sword comes play, but if you keep spamming the melee button after he just skips those frames and goes directly to the hit (Apply the same thing to the gun if you can)